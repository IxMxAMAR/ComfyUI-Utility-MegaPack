"""Operations registered on ProgrammingNode."""
