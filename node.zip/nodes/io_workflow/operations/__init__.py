"""Operations for IOWorkflowNode."""
