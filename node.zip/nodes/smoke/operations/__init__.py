"""Operations registered on SmokeTestNode."""
