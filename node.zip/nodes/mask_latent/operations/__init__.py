"""Operations for MaskLatentNode."""
