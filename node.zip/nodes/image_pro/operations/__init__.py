"""Operations registered on ImageProNode."""
