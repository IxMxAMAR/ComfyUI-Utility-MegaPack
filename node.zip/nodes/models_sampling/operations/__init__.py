"""Operations for ModelsSamplingNode."""
