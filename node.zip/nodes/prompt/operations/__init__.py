"""Operations registered on PromptNode."""
